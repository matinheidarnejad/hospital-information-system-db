import database as db

# =============================================
# Function 1: Get Patient Full Name
# =============================================
def get_patient_full_name(patient_id):
    return db.execute_function('fn_GetPatientFullName', [patient_id])

# =============================================
# Function 2: Calculate Patient Age
# =============================================
def calculate_patient_age(patient_id):
    return db.execute_function('fn_CalculatePatientAge', [patient_id])

# =============================================
# Function 3: Get Bed Availability
# =============================================
def get_bed_availability(department_id):
    return db.execute_function('fn_GetBedAvailability', [department_id])

# =============================================
# Function 4: Get Total Patient Payments
# =============================================
def get_total_patient_payments(patient_id):
    return db.execute_function('fn_GetTotalPatientPayments', [patient_id])

# =============================================
# Function 5: Get Patient Balance
# =============================================
def get_patient_balance(patient_id):
    return db.execute_function('fn_GetPatientBalance', [patient_id])

# =============================================
# Function 6: Get Doctor Appointment Count
# =============================================
def get_doctor_appointment_count(staff_id, start_date, end_date):
    return db.execute_function('fn_GetDoctorAppointmentCount', [staff_id, start_date, end_date])

# =============================================
# Function 7: Get Department Bed Occupancy Rate
# =============================================
def get_department_bed_occupancy_rate(department_id):
    return db.execute_function('fn_GetDepartmentBedOccupancyRate', [department_id])

# =============================================
# Function 8: Get Critical Lab Results
# =============================================
def get_critical_lab_results(patient_id):
    return db.execute_function('fn_GetCriticalLabResults', [patient_id])

# =============================================
# Function 9: Get Inventory Item Stock
# =============================================
def get_inventory_item_stock(item_id):
    return db.execute_function('fn_GetInventoryItemStock', [item_id])

# =============================================
# Function 10: Get Total Appointments Per Day
# =============================================
def get_total_appointments_per_day(date):
    return db.execute_function('fn_GetTotalAppointmentsPerDay', [date])

# =============================================
# Function 11: Get Active IoT Devices Count
# =============================================
def get_active_iot_devices_count():
    return db.execute_function('fn_GetActiveIoTDevicesCount', [])

# =============================================
# Function 12: Get Unchecked Alerts Count
# =============================================
def get_unchecked_alerts_count():
    return db.execute_function('fn_GetUncheckedAlertsCount', [])

# =============================================
# Function 13: Get Patient Admission History
# =============================================
def get_patient_admission_history(patient_id):
    return db.execute_function('fn_GetPatientAdmissionHistory', [patient_id])

# =============================================
# Function 14: Get Prescription Details
# =============================================
def get_prescription_details(prescription_id):
    return db.execute_function('fn_GetPrescriptionDetails', [prescription_id])

# =============================================
# Function 15: Get Department Full Info
# =============================================
def get_department_full_info(department_id):
    return db.execute_function('fn_GetDepartmentFullInfo', [department_id])

# =============================================
# Function 16: Get Pending Invoices Count
# =============================================
def get_pending_invoices_count():
    return db.execute_function('fn_GetPendingInvoicesCount', [])

# =============================================
# Function 17: Get Lab Request Status
# =============================================
def get_lab_request_status(result_id):
    return db.execute_function('fn_GetLabRequestStatus', [result_id])

# =============================================
# Function 18: Get Drug Interaction Count
# =============================================
def get_drug_interaction_count(item_id):
    return db.execute_function('fn_GetDrugInteractionCount', [item_id])

# =============================================
# Function 19: Get Patient Appointment History
# =============================================
def get_patient_appointment_history(patient_id):
    return db.execute_function('fn_GetPatientAppointmentHistory', [patient_id])

# =============================================
# Function 20: Get Staff Workload
# =============================================
def get_staff_workload(staff_id):
    return db.execute_function('fn_GetStaffWorkload', [staff_id])

# =============================================
# Function 21: Get Inventory Turnover
# =============================================
def get_inventory_turnover(item_id):
    return db.execute_function('fn_GetInventoryTurnover', [item_id])

# =============================================
# Function 22: Get Patient Insurance Coverage
# =============================================
def get_patient_insurance_coverage(patient_id):
    return db.execute_function('fn_GetPatientInsuranceCoverage', [patient_id])

# =============================================
# Function 23: Get Available Beds For Department
# =============================================
def get_available_beds_for_department(department_id):
    return db.execute_function('fn_GetAvailableBedsForDepartment', [department_id])