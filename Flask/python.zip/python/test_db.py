import database as db

def test_connection():
    conn = db.get_db_connection()
    if conn:
        print("✅ اتصال به دیتابیس برقرار شد!")
        conn.close()
    else:
        print("❌ اتصال به دیتابیس FAIL شد!")

if __name__ == "__main__":
    test_connection()