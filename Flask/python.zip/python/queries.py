# =====================================================
# بخش ۱: بیماران
# =====================================================
GET_ALL_PATIENTS = """
SELECT PatientID, NationalID, FirstName, LastName, Gender, DOB, Phone, Address
FROM Patients
ORDER BY PatientID
"""

GET_PATIENT_BY_NATIONAL_ID = """
SELECT * FROM Patients WHERE NationalID = ?
"""

GET_PATIENT_MEDICAL_HISTORY = """
SELECT 
    p.PatientID,
    p.NationalID,
    p.FirstName,
    p.LastName,
    p.Gender,
    p.DOB,
    p.Phone,
    p.Address,
    mh.ICD_Code,
    mh.Diagnosis,
    mh.MedicationHistory,
    mh.SmokingHistory,
    mh.Height_cm,
    mh.Weight_kg,
    mh.BloodPressure,
    mh.RecordDate
FROM Patients p
LEFT JOIN Medical_Records mr ON p.PatientID = mr.PatientID
LEFT JOIN Medical_History mh ON mr.RecordID = mh.RecordID
WHERE p.PatientID = ?
ORDER BY mh.RecordDate DESC
"""

# =====================================================
# بخش ۲: نوبت‌ها
# =====================================================
GET_TODAY_APPOINTMENTS = """
SELECT 
    a.AppointmentID,
    p.FirstName AS PatientFirstName,
    p.LastName AS PatientLastName,
    s.FirstName AS DoctorFirstName,
    s.LastName AS DoctorLastName,
    a.ApptDate,
    a.ApptType,
    a.Status
FROM Appointments a
JOIN Patients p ON a.PatientID = p.PatientID
LEFT JOIN Staff s ON a.StaffID = s.StaffID
WHERE CAST(a.ApptDate AS DATE) = CAST(GETDATE() AS DATE)
"""

# =====================================================
# بخش ۳: تخت‌ها
# =====================================================
GET_ALL_BEDS = """
SELECT 
    d.DeptName,
    b.BedID,
    b.Status
FROM Beds b
JOIN Departments d ON b.DepartmentID = d.DepartmentID
ORDER BY d.DeptName, b.BedID
"""

# =====================================================
# بخش ۴: آزمایشگاه
# =====================================================
GET_ALL_LAB_RESULTS = """
SELECT 
    lr.ResultID,
    p.FirstName AS PatientFirstName,
    p.LastName AS PatientLastName,
    lr.TestType,
    lr.ResultDetails,
    lr.IsCritical,
    lr.Status,
    lr.TestDate
FROM Lab_Results lr
JOIN Patients p ON lr.PatientID = p.PatientID
"""

# =====================================================
# بخش ۵: داروخانه
# =====================================================
GET_ALL_PRESCRIPTIONS = """
SELECT 
    pr.PrescriptionID,
    p.FirstName AS PatientFirstName,
    p.LastName AS PatientLastName,
    s.FirstName AS DoctorFirstName,
    s.LastName AS DoctorLastName,
    pr.IssueDate,
    ii.ItemName,
    pi.Quantity
FROM Prescriptions pr
JOIN Patients p ON pr.PatientID = p.PatientID
JOIN Staff s ON pr.StaffID = s.StaffID
LEFT JOIN Prescription_Items pi ON pr.PrescriptionID = pi.PrescriptionID
LEFT JOIN Inventory_Items ii ON pi.ItemID = ii.ItemID
"""

# =====================================================
# بخش ۶: مالی
# =====================================================
GET_ALL_INVOICES = """
SELECT 
    i.InvoiceID,
    p.FirstName AS PatientFirstName,
    p.LastName AS PatientLastName,
    i.TotalAmount,
    i.InsuranceShare,
    i.PatientShare,
    i.Status
FROM Invoices i
JOIN Patients p ON i.PatientID = p.PatientID
"""

# =====================================================
# بخش ۷: IoT
# =====================================================
GET_ALL_IOT_DEVICES = """
SELECT 
    MAC_Address,
    DeviceType,
    Status,
    PatientID,
    BedID
FROM IoT_Devices
"""

# =====================================================
# بخش ۸: هشدارها
# =====================================================
GET_ALL_ALERTS = """
SELECT 
    AlertID,
    LogID,
    ResultID,
    Severity,
    Status,
    GeneratedAt,
    ResolvedAt,
    s.FirstName AS ResponderFirstName,
    s.LastName AS ResponderLastName
FROM Alerts a
LEFT JOIN Staff s ON a.ResponderID = s.StaffID
ORDER BY GeneratedAt DESC
"""