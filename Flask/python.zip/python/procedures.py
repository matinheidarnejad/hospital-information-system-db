import database as db
from datetime import datetime

# =============================================
# Procedure 1: Register Patient
# =============================================
def register_patient(national_id, first_name, last_name, gender, dob, phone, address):
    conn = db.get_db_connection()
    if conn is None:
        return {'success': False, 'message': 'اتصال به دیتابیس برقرار نشد.'}
    try:
        cursor = conn.cursor()
        
        # تعریف متغیر خروجی
        cursor.execute("""
            DECLARE @PatientID INT;
            EXEC sp_RegisterPatient 
                @NationalID = ?,
                @FirstName = ?,
                @LastName = ?,
                @Gender = ?,
                @DOB = ?,
                @Phone = ?,
                @Address = ?,
                @PatientID = @PatientID OUTPUT;
            SELECT @PatientID AS PatientID;
        """, (national_id, first_name, last_name, gender, dob, phone, address))
        
        row = cursor.fetchone()
        conn.commit()
        conn.close()
        
        if row and row.PatientID:
            return {'success': True, 'message': f'بیمار با موفقیت ثبت شد. ID: {row.PatientID}'}
        else:
            return {'success': False, 'message': 'خطا در ثبت بیمار.'}
    except Exception as e:
        conn.close()
        return {'success': False, 'message': str(e)}

# =============================================
# Procedure 2: Book Appointment
# =============================================
def book_appointment(patient_id, staff_id, department_id, appt_date, appt_type):
    conn = db.get_db_connection()
    if conn is None:
        return {'success': False, 'message': 'اتصال به دیتابیس برقرار نشد.'}
    try:
        cursor = conn.cursor()
        cursor.execute("""
            DECLARE @AppointmentID INT;
            EXEC sp_BookAppointment 
                @PatientID = ?,
                @StaffID = ?,
                @DepartmentID = ?,
                @ApptDate = ?,
                @ApptType = ?,
                @AppointmentID = @AppointmentID OUTPUT;
            SELECT @AppointmentID AS AppointmentID;
        """, (patient_id, staff_id, department_id, appt_date, appt_type))
        row = cursor.fetchone()
        conn.commit()
        conn.close()
        
        if row and row.AppointmentID:
            return {'success': True, 'message': f'نوبت با موفقیت ثبت شد. ID: {row.AppointmentID}'}
        else:
            return {'success': False, 'message': 'خطا در ثبت نوبت.'}
    except Exception as e:
        conn.close()
        return {'success': False, 'message': str(e)}

# =============================================
# Procedure 3: Admit Patient
# =============================================
def admit_patient(patient_id, bed_id, start_date):
    conn = db.get_db_connection()
    if conn is None:
        return {'success': False, 'message': 'اتصال به دیتابیس برقرار نشد.'}
    try:
        cursor = conn.cursor()
        cursor.execute("""
            DECLARE @TransferID INT;
            EXEC sp_AdmitPatient 
                @PatientID = ?,
                @BedID = ?,
                @StartDate = ?,
                @TransferID = @TransferID OUTPUT;
            SELECT @TransferID AS TransferID;
        """, (patient_id, bed_id, start_date))
        row = cursor.fetchone()
        conn.commit()
        conn.close()
        
        if row and row.TransferID:
            return {'success': True, 'message': f'بیمار با موفقیت بستری شد. ID: {row.TransferID}'}
        else:
            return {'success': False, 'message': 'خطا در بستری بیمار.'}
    except Exception as e:
        conn.close()
        return {'success': False, 'message': str(e)}

# =============================================
# Procedure 4: Transfer Patient
# =============================================
def transfer_patient(patient_id, new_bed_id, transfer_date):
    conn = db.get_db_connection()
    if conn is None:
        return {'success': False, 'message': 'اتصال به دیتابیس برقرار نشد.'}
    try:
        cursor = conn.cursor()
        cursor.execute("""
            DECLARE @TransferID INT;
            EXEC sp_TransferPatient 
                @PatientID = ?,
                @NewBedID = ?,
                @TransferDate = ?,
                @TransferID = @TransferID OUTPUT;
            SELECT @TransferID AS TransferID;
        """, (patient_id, new_bed_id, transfer_date))
        row = cursor.fetchone()
        conn.commit()
        conn.close()
        
        if row and row.TransferID:
            return {'success': True, 'message': f'بیمار با موفقیت جابجا شد. ID: {row.TransferID}'}
        else:
            return {'success': False, 'message': 'خطا در جابجایی بیمار.'}
    except Exception as e:
        conn.close()
        return {'success': False, 'message': str(e)}

# =============================================
# Procedure 5: Dispense Prescription
# =============================================
def dispense_prescription(prescription_id):
    conn = db.get_db_connection()
    if conn is None:
        return {'success': False, 'message': 'اتصال به دیتابیس برقرار نشد.'}
    try:
        cursor = conn.cursor()
        cursor.execute("""
            DECLARE @Success BIT;
            EXEC sp_DispensePrescription 
                @PrescriptionID = ?,
                @Success = @Success OUTPUT;
            SELECT @Success AS Success;
        """, (prescription_id,))
        row = cursor.fetchone()
        conn.commit()
        conn.close()
        
        if row and row.Success == 1:
            return {'success': True, 'message': 'نسخه با موفقیت تحویل داده شد.'}
        else:
            return {'success': False, 'message': 'خطا در تحویل نسخه.'}
    except Exception as e:
        conn.close()
        return {'success': False, 'message': str(e)}

# =============================================
# Procedure 6: Record Lab Result
# =============================================
def record_lab_result(result_id, result_details, is_critical):
    conn = db.get_db_connection()
    if conn is None:
        return {'success': False, 'message': 'اتصال به دیتابیس برقرار نشد.'}
    try:
        cursor = conn.cursor()
        cursor.execute("""
            EXEC sp_RecordLabResult 
                @ResultID = ?,
                @ResultDetails = ?,
                @IsCritical = ?;
        """, (result_id, result_details, is_critical))
        conn.commit()
        conn.close()
        return {'success': True, 'message': 'نتیجه آزمایش با موفقیت ثبت شد.'}
    except Exception as e:
        conn.close()
        return {'success': False, 'message': str(e)}

# =============================================
# Procedure 7: Record Payment
# =============================================
def record_payment(invoice_id, amount, payment_type):
    conn = db.get_db_connection()
    if conn is None:
        return {'success': False, 'message': 'اتصال به دیتابیس برقرار نشد.'}
    try:
        cursor = conn.cursor()
        cursor.execute("""
            DECLARE @PaymentID INT;
            EXEC sp_RecordPayment 
                @InvoiceID = ?,
                @Amount = ?,
                @PaymentType = ?,
                @PaymentID = @PaymentID OUTPUT;
            SELECT @PaymentID AS PaymentID;
        """, (invoice_id, amount, payment_type))
        row = cursor.fetchone()
        conn.commit()
        conn.close()
        
        if row and row.PaymentID:
            return {'success': True, 'message': f'پرداخت با موفقیت ثبت شد. ID: {row.PaymentID}'}
        else:
            return {'success': False, 'message': 'خطا در ثبت پرداخت.'}
    except Exception as e:
        conn.close()
        return {'success': False, 'message': str(e)}

# =============================================
# Procedure 8: Discharge Patient
# =============================================
def discharge_patient(patient_id, discharge_date):
    conn = db.get_db_connection()
    if conn is None:
        return {'success': False, 'message': 'اتصال به دیتابیس برقرار نشد.'}
    try:
        cursor = conn.cursor()
        cursor.execute("""
            DECLARE @Success BIT;
            EXEC sp_DischargePatient 
                @PatientID = ?,
                @DischargeDate = ?,
                @Success = @Success OUTPUT;
            SELECT @Success AS Success;
        """, (patient_id, discharge_date))
        row = cursor.fetchone()
        conn.commit()
        conn.close()
        
        if row and row.Success == 1:
            return {'success': True, 'message': 'بیمار با موفقیت ترخیص شد.'}
        else:
            return {'success': False, 'message': 'خطا در ترخیص بیمار.'}
    except Exception as e:
        conn.close()
        return {'success': False, 'message': str(e)}

# =============================================
# Procedure 9: Generate Invoice
# =============================================
def generate_invoice(patient_id):
    conn = db.get_db_connection()
    if conn is None:
        return {'success': False, 'message': 'اتصال به دیتابیس برقرار نشد.'}
    try:
        cursor = conn.cursor()
        cursor.execute("""
            DECLARE @InvoiceID INT;
            EXEC sp_GenerateInvoice 
                @PatientID = ?,
                @InvoiceID = @InvoiceID OUTPUT;
            SELECT @InvoiceID AS InvoiceID;
        """, (patient_id,))
        row = cursor.fetchone()
        conn.commit()
        conn.close()
        
        if row and row.InvoiceID:
            return {'success': True, 'message': f'فاکتور با موفقیت تولید شد. ID: {row.InvoiceID}'}
        else:
            return {'success': False, 'message': 'خطا در تولید فاکتور.'}
    except Exception as e:
        conn.close()
        return {'success': False, 'message': str(e)}

# =============================================
# Procedure 10: Update Patient
# =============================================
def update_patient(patient_id, national_id, first_name, last_name, gender, dob, phone, address):
    conn = db.get_db_connection()
    if conn is None:
        return {'success': False, 'message': 'Database connection failed.'}
    try:
        cursor = conn.cursor()
        cursor.execute("""
            DECLARE @UpdatedID INT;
            EXEC sp_UpdatePatient 
                @PatientID = ?,
                @NationalID = ?,
                @FirstName = ?,
                @LastName = ?,
                @Gender = ?,
                @DOB = ?,
                @Phone = ?,
                @Address = ?;
        """, (patient_id, national_id, first_name, last_name, gender, dob, phone, address))
        conn.commit()
        conn.close()
        return {'success': True, 'message': 'Patient information successfully updated.'}
    except Exception as e:
        conn.close()
        return {'success': False, 'message': str(e)}

# =============================================
# Procedure 11: Add Medical History
# =============================================
def add_medical_history(patient_id, icd_code, diagnosis, medication_history=None, 
                        smoking_history=None, height_cm=None, weight_kg=None, 
                        blood_pressure=None, record_date=None):
    conn = db.get_db_connection()
    if conn is None:
        return {'success': False, 'message': 'Database connection failed.'}
    try:
        cursor = conn.cursor()
        
        # اگه تاریخ ارسال نشده، از تاریخ امروز استفاده کن
        if record_date is None or record_date == '':
            record_date = datetime.now().strftime('%Y-%m-%d')
        
        cursor.execute("""
            DECLARE @HistoryID INT;
            EXEC sp_AddMedicalHistory 
                @PatientID = ?,
                @ICD_Code = ?,
                @Diagnosis = ?,
                @MedicationHistory = ?,
                @SmokingHistory = ?,
                @Height_cm = ?,
                @Weight_kg = ?,
                @BloodPressure = ?,
                @RecordDate = ?;
            SELECT @HistoryID = SCOPE_IDENTITY();
            SELECT @HistoryID AS HistoryID;
        """, (patient_id, icd_code, diagnosis, medication_history, smoking_history, 
              height_cm, weight_kg, blood_pressure, record_date))
        
        row = cursor.fetchone()
        conn.commit()
        conn.close()
        
        if row and row.HistoryID:
            return {'success': True, 'message': f'Medical history successfully added. ID: {row.HistoryID}'}
        else:
            return {'success': False, 'message': 'Failed to add medical history.'}
    except Exception as e:
        conn.close()
        return {'success': False, 'message': str(e)}

# =============================================
# Procedure 12: Prescribe Medicine (تجویز دارو)
# =============================================
def prescribe_medicine(patient_id, staff_id, item_id, quantity):
    conn = db.get_db_connection()
    if conn is None:
        return {'success': False, 'message': 'اتصال به دیتابیس برقرار نشد.'}
    try:
        cursor = conn.cursor()
        cursor.execute("""
            DECLARE @PrescriptionID INT;
            EXEC sp_PrescribeMedicine 
                @PatientID = ?,
                @StaffID = ?,
                @ItemID = ?,
                @Quantity = ?,
                @PrescriptionID = @PrescriptionID OUTPUT;
            SELECT @PrescriptionID AS PrescriptionID;
        """, (patient_id, staff_id, item_id, quantity))
        row = cursor.fetchone()
        conn.commit()
        conn.close()
        
        if row and row.PrescriptionID:
            return {'success': True, 'message': f'دارو با موفقیت تجویز شد. ID نسخه: {row.PrescriptionID}'}
        else:
            return {'success': False, 'message': 'خطا در تجویز دارو.'}
    except Exception as e:
        conn.close()
        return {'success': False, 'message': str(e)}

# =============================================
# Procedure 13: Request Lab Test (درخواست آزمایش)
# =============================================
def request_lab_test(patient_id, staff_id, test_type, department_id=None):
    conn = db.get_db_connection()
    if conn is None:
        return {'success': False, 'message': 'اتصال به دیتابیس برقرار نشد.'}
    try:
        cursor = conn.cursor()
        cursor.execute("""
            DECLARE @ResultID INT;
            EXEC sp_RequestLabTest 
                @PatientID = ?,
                @StaffID = ?,
                @TestType = ?,
                @DepartmentID = ?,
                @ResultID = @ResultID OUTPUT;
            SELECT @ResultID AS ResultID;
        """, (patient_id, staff_id, test_type, department_id))
        row = cursor.fetchone()
        conn.commit()
        conn.close()
        
        if row and row.ResultID:
            return {'success': True, 'message': f'درخواست آزمایش با موفقیت ثبت شد. ID: {row.ResultID}'}
        else:
            return {'success': False, 'message': 'خطا در ثبت درخواست آزمایش.'}
    except Exception as e:
        conn.close()
        return {'success': False, 'message': str(e)}

# =============================================
# Procedure 14: Get Pending Lab Requests
# =============================================
def get_pending_lab_requests():
    conn = db.get_db_connection()
    if conn is None:
        return []
    try:
        cursor = conn.cursor()
        cursor.execute("EXEC sp_GetPendingLabRequests")
        rows = cursor.fetchall()
        conn.close()
        
        result = []
        for row in rows:
            result.append({
                'ResultID': row.ResultID,
                'PatientName': row.PatientName,
                'NationalID': row.NationalID,
                'DoctorName': row.DoctorName,
                'TestType': row.TestType,
                'RequestDate': row.RequestDate,
                'Status': row.Status
            })
        return result
    except Exception as e:
        print(f"Error in get_pending_lab_requests: {e}")
        conn.close()
        return []



        