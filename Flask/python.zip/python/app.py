from flask import Flask, render_template, request, jsonify
from datetime import datetime
import database as db
import queries
import functions as fn
import procedures as proc

app = Flask(__name__)

# =============================================
# صفحه اصلی (داشبورد)
# =============================================
@app.route('/')
def index():
    # گرفتن تعداد واقعی بیماران از دیتابیس
    total_patients_result = db.execute_query("SELECT COUNT(*) AS Count FROM Patients")
    total_patients = total_patients_result[0].Count if total_patients_result else 0
    
    pending_invoices = db.execute_function('fn_GetPendingInvoicesCount', []) or 0
    active_iot = db.execute_function('fn_GetActiveIoTDevicesCount', []) or 0
    unchecked_alerts = db.execute_function('fn_GetUncheckedAlertsCount', []) or 0
    
    now = datetime.now()
    
    return render_template('index.html',
                         total_patients=total_patients,
                         pending_invoices=pending_invoices,
                         active_iot=active_iot,
                         unchecked_alerts=unchecked_alerts,
                         now=now)

# =============================================
# بیماران
# =============================================
@app.route('/patients')
def patients():
    rows = db.execute_query(queries.GET_ALL_PATIENTS)
    return render_template('patients.html', patients=rows)

@app.route('/patient/<int:patient_id>')
def patient_detail(patient_id):
    # گرفتن اطلاعات بیمار
    patient_row = db.execute_query("SELECT * FROM Patients WHERE PatientID = ?", (patient_id,))
    patient = patient_row[0] if patient_row else None
    
    if patient is None:
        return render_template('patient_detail.html', patient=None, medical_history=[])
    
    # گرفتن تاریخچه پزشکی بیمار
    history_rows = db.execute_query(queries.GET_PATIENT_MEDICAL_HISTORY, (patient_id,))
    
    # تبدیل به دیکشنری برای راحتی
    medical_history = []
    for row in history_rows:
        medical_history.append({
            'ICD_Code': row.ICD_Code,
            'Diagnosis': row.Diagnosis,
            'MedicationHistory': row.MedicationHistory,
            'SmokingHistory': row.SmokingHistory,
            'Height_cm': row.Height_cm,
            'Weight_kg': row.Weight_kg,
            'BloodPressure': row.BloodPressure,
            'RecordDate': row.RecordDate
        })
    
    # اطلاعات بیمار رو از ردیف اول بگیر
    if history_rows:
        patient_data = {
            'PatientID': history_rows[0].PatientID,
            'NationalID': history_rows[0].NationalID,
            'FirstName': history_rows[0].FirstName,
            'LastName': history_rows[0].LastName,
            'Gender': history_rows[0].Gender,
            'DOB': history_rows[0].DOB,
            'Phone': history_rows[0].Phone,
            'Address': history_rows[0].Address,
            'ICD_Code': history_rows[0].ICD_Code,
            'Diagnosis': history_rows[0].Diagnosis
        }
    else:
        # اگه تاریخچه نداشت، فقط اطلاعات بیمار رو نشون بده
        patient_data = {
            'PatientID': patient.PatientID,
            'NationalID': patient.NationalID,
            'FirstName': patient.FirstName,
            'LastName': patient.LastName,
            'Gender': patient.Gender,
            'DOB': patient.DOB,
            'Phone': patient.Phone,
            'Address': patient.Address,
            'ICD_Code': None,
            'Diagnosis': None
        }
    
    return render_template('patient_detail.html', patient=patient_data, medical_history=medical_history)

# =============================================
# ویرایش بیمار
# =============================================
@app.route('/edit_patient/<int:patient_id>')
def edit_patient(patient_id):
    row = db.execute_query("SELECT * FROM Patients WHERE PatientID = ?", (patient_id,))
    patient = row[0] if row else None
    if patient is None:
        return "Patient not found", 404
    return render_template('edit_patient.html', patient=patient)

@app.route('/api/update_patient', methods=['POST'])
def update_patient_api():
    try:
        data = request.get_json()
        result = proc.update_patient(
            data['PatientID'],
            data['NationalID'],
            data['FirstName'],
            data['LastName'],
            data['Gender'],
            data['DOB'],
            data['Phone'],
            data['Address']
        )
        return jsonify(result)
    except Exception as e:
        return jsonify({'success': False, 'message': str(e)}), 500
    
# =============================================
# پنل پزشکان
# =============================================
@app.route('/doctor_dashboard')
def doctor_dashboard():
    rows = db.execute_query(queries.GET_ALL_PATIENTS)
    return render_template('doctor_dashboard.html', patients=rows)

@app.route('/add_medical_record/<int:patient_id>')
def add_medical_record(patient_id):
    row = db.execute_query("SELECT * FROM Patients WHERE PatientID = ?", (patient_id,))
    patient = row[0] if row else None
    if patient is None:
        return "Patient not found", 404
    
    today = datetime.now().strftime('%Y-%m-%d')
    return render_template('add_medical_record.html', patient=patient, today=today)

@app.route('/api/add_medical_history', methods=['POST'])
def add_medical_history_api():
    try:
        data = request.get_json()
        result = proc.add_medical_history(
            data['PatientID'],
            data['ICD_Code'],
            data['Diagnosis'],
            data.get('MedicationHistory'),
            data.get('SmokingHistory'),
            data.get('Height_cm'),
            data.get('Weight_kg'),
            data.get('BloodPressure'),
            data.get('RecordDate')
        )
        return jsonify(result)
    except Exception as e:
        return jsonify({'success': False, 'message': str(e)}), 500

# =============================================
# ثبت نوبت جدید
# =============================================
@app.route('/new_appointment')
def new_appointment():
    # گرفتن لیست بیماران و پزشکان برای نمایش در فرم
    patients = db.execute_query("SELECT PatientID, FirstName, LastName FROM Patients ORDER BY FirstName")
    doctors = db.execute_query("SELECT StaffID, FirstName, LastName FROM Staff WHERE Role = 'Doctor' ORDER BY FirstName")
    departments = db.execute_query("SELECT DepartmentID, DeptName FROM Departments ORDER BY DeptName")
    return render_template('new_appointment.html', patients=patients, doctors=doctors, departments=departments)

@app.route('/api/book_appointment', methods=['POST'])
def book_appointment_api():
    try:
        data = request.get_json()
        print("=" * 60)
        print(f"📌 Book Appointment API")
        print(f"📥 Data received: {data}")
        print("=" * 60)
        
        result = proc.book_appointment(
            data['PatientID'],
            data.get('StaffID'),
            data.get('DepartmentID'),
            data['ApptDate'],
            data['ApptType']
        )
        
        print(f"📤 Result: {result}")
        print("=" * 60)
        
        return jsonify(result)
    except Exception as e:
        print(f"❌ Exception: {str(e)}")
        import traceback
        traceback.print_exc()
        return jsonify({'success': False, 'message': str(e)}), 500
    
# =============================================
# نوبت‌ها
# =============================================
@app.route('/appointments')
def appointments():
    rows = db.execute_query(queries.GET_TODAY_APPOINTMENTS)
    return render_template('appointments.html', appointments=rows)

# =============================================
# تخت‌ها
# =============================================
@app.route('/beds')
def beds():
    rows = db.execute_query(queries.GET_ALL_BEDS)
    return render_template('beds.html', beds=rows)

# =============================================
# آزمایشگاه
# =============================================
@app.route('/lab_results')
def lab_results():
    rows = db.execute_query(queries.GET_ALL_LAB_RESULTS)
    return render_template('lab_results.html', results=rows)

# =============================================
# آزمایشگاه - مدیریت درخواست‌ها
# =============================================
@app.route('/lab_pending_requests')
def lab_pending_requests():
    requests = proc.get_pending_lab_requests()
    return render_template('lab_pending_requests.html', requests=requests)

@app.route('/lab_record_result/<int:result_id>')
def lab_record_result(result_id):
    # گرفتن اطلاعات درخواست
    rows = db.execute_query("""
        SELECT 
            lr.ResultID,
            p.FirstName + ' ' + p.LastName AS PatientName,
            p.NationalID,
            s.FirstName + ' ' + s.LastName AS DoctorName,
            lr.TestType,
            lr.TestDate AS RequestDate
        FROM Lab_Results lr
        JOIN Patients p ON lr.PatientID = p.PatientID
        JOIN Staff s ON lr.StaffID = s.StaffID
        WHERE lr.ResultID = ?
    """, (result_id,))
    
    if not rows:
        return "Request not found", 404
    
    request_data = {
        'ResultID': rows[0].ResultID,
        'PatientName': rows[0].PatientName,
        'NationalID': rows[0].NationalID,
        'DoctorName': rows[0].DoctorName,
        'TestType': rows[0].TestType,
        'RequestDate': rows[0].RequestDate
    }
    
    return render_template('lab_record_result.html', request=request_data)

@app.route('/api/lab_record_result', methods=['POST'])
def lab_record_result_api():
    try:
        data = request.get_json()
        result = proc.record_lab_result(
            data['ResultID'],
            data['ResultDetails'],
            data['IsCritical']
        )
        return jsonify(result)
    except Exception as e:
        return jsonify({'success': False, 'message': str(e)}), 500

# =============================================
# داروخانه
# =============================================
@app.route('/prescriptions')
def prescriptions():
    rows = db.execute_query(queries.GET_ALL_PRESCRIPTIONS)
    return render_template('prescriptions.html', prescriptions=rows)

# =============================================
# مالی
# =============================================
@app.route('/invoices')
def invoices():
    rows = db.execute_query(queries.GET_ALL_INVOICES)
    return render_template('invoices.html', invoices=rows)

# =============================================
# IoT
# =============================================
@app.route('/iot_devices')
def iot_devices():
    rows = db.execute_query(queries.GET_ALL_IOT_DEVICES)
    return render_template('iot_devices.html', devices=rows)

# =============================================
# هشدارها
# =============================================
@app.route('/alerts')
def alerts():
    rows = db.execute_query(queries.GET_ALL_ALERTS)
    return render_template('alerts.html', alerts=rows)

# =============================================
# Functionها (API)
# =============================================
@app.route('/functions')
def functions_page():
    return render_template('functions.html')

@app.route('/api/function/<func_name>')
def call_function(func_name):
    params = request.args.getlist('params')
    params = [p for p in params if p and p != '']
    result = db.execute_function(func_name, params if params else None)
    return jsonify({'result': result})

# =============================================
# Procedureها (API)
# =============================================
@app.route('/procedures')
def procedures_page():
    return render_template('procedures.html')

@app.route('/api/procedure/<proc_name>', methods=['POST'])
def call_procedure(proc_name):
    try:
        data = request.get_json()
        params = data.get('params', [])
        
        # لاگ گرفتن از درخواست
        print("=" * 60)
        print(f"📌 Procedure: {proc_name}")
        print(f"📥 Params received: {params}")
        print("=" * 60)
        
        while params and (params[-1] is None or params[-1] == ''):
            params.pop()
        
        # تبدیل '' به None برای پارامترهای اختیاری
        params = [p if p != '' else None for p in params]
        
        print(f"📤 Final params: {params}")
        
        result = None
        if proc_name == 'sp_RegisterPatient':
            result = proc.register_patient(*params)
        elif proc_name == 'sp_BookAppointment':
            result = proc.book_appointment(*params)
        elif proc_name == 'sp_AdmitPatient':
            result = proc.admit_patient(*params)
        elif proc_name == 'sp_TransferPatient':
            result = proc.transfer_patient(*params)
        elif proc_name == 'sp_DispensePrescription':
            result = proc.dispense_prescription(*params)
        elif proc_name == 'sp_RecordLabResult':
            result = proc.record_lab_result(*params)
        elif proc_name == 'sp_RecordPayment':
            result = proc.record_payment(*params)
        else:
            return jsonify({'result': 'Invalid procedure name.'}), 400
        
        print(f"📤 Result: {result}")
        print("=" * 60)
        
        if result and result.get('success'):
            return jsonify({'result': result.get('message', 'Operation completed successfully.')})
        else:
            error_msg = result.get('message', 'Error executing procedure') if result else 'Error executing procedure'
            print(f"❌ Error: {error_msg}")
            return jsonify({'result': error_msg}), 500
            
    except Exception as e:
        print(f"❌ Exception: {str(e)}")
        import traceback
        traceback.print_exc()
        return jsonify({'result': f'Error: {str(e)}'}), 500

# =============================================
# تجویز دارو توسط پزشک
# =============================================
@app.route('/doctor_prescribe/<int:patient_id>')
def doctor_prescribe(patient_id):
    # گرفتن اطلاعات بیمار
    patient_row = db.execute_query("SELECT * FROM Patients WHERE PatientID = ?", (patient_id,))
    patient = patient_row[0] if patient_row else None
    if patient is None:
        return "Patient not found", 404
    
    # گرفتن لیست پزشکان و داروها
    doctors = db.execute_query("SELECT StaffID, FirstName, LastName FROM Staff WHERE Role = 'Doctor' ORDER BY FirstName")
    medicines = db.execute_query("SELECT ItemID, ItemName, CurrentStock FROM Inventory_Items WHERE ItemType = 'Medicine' ORDER BY ItemName")
    
    return render_template('doctor_prescribe.html', patient=patient, doctors=doctors, medicines=medicines)

@app.route('/api/prescribe_medicine', methods=['POST'])
def prescribe_medicine_api():
    try:
        data = request.get_json()
        result = proc.prescribe_medicine(
            data['PatientID'],
            data['StaffID'],
            data['ItemID'],
            data['Quantity']
        )
        return jsonify(result)
    except Exception as e:
        return jsonify({'success': False, 'message': str(e)}), 500

# =============================================
# درخواست آزمایش توسط پزشک
# =============================================
@app.route('/doctor_lab_request/<int:patient_id>')
def doctor_lab_request(patient_id):
    # گرفتن اطلاعات بیمار
    patient_row = db.execute_query("SELECT * FROM Patients WHERE PatientID = ?", (patient_id,))
    patient = patient_row[0] if patient_row else None
    if patient is None:
        return "Patient not found", 404
    
    # گرفتن لیست پزشکان و بخش‌ها
    doctors = db.execute_query("SELECT StaffID, FirstName, LastName FROM Staff WHERE Role = 'Doctor' ORDER BY FirstName")
    departments = db.execute_query("SELECT DepartmentID, DeptName FROM Departments ORDER BY DeptName")
    
    return render_template('doctor_lab_request.html', patient=patient, doctors=doctors, departments=departments)

@app.route('/api/request_lab_test', methods=['POST'])
def request_lab_test_api():
    try:
        data = request.get_json()
        result = proc.request_lab_test(
            data['PatientID'],
            data['StaffID'],
            data['TestType'],
            data.get('DepartmentID')
        )
        return jsonify(result)
    except Exception as e:
        return jsonify({'success': False, 'message': str(e)}), 500

# =============================================
# تولید فاکتور تجمیعی برای بیمار
# =============================================
@app.route('/generate_invoice/<int:patient_id>', methods=['POST'])
def generate_invoice_api(patient_id):
    try:
        result = proc.generate_consolidated_invoice(patient_id)
        return jsonify(result)
    except Exception as e:
        return jsonify({'success': False, 'message': str(e)}), 500

# =============================================
# اجرای برنامه
# =============================================
if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0', port=5000)