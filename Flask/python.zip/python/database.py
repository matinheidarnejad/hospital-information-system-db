import pyodbc

# =============================================
# تنظیمات اتصال به SQL Server
# =============================================
DB_CONFIG = {
    'server': 'Mokhtari\\ReichSQL',       
    'database': 'HospitalDB',
    'username': 'sa',
    'password': 'AaSs577571178448',               
    'driver': '{ODBC Driver 17 for SQL Server}',
    'trust_server_certificate': 'yes'
}

def get_connection_string():
    return (
        f"DRIVER={DB_CONFIG['driver']};"
        f"SERVER={DB_CONFIG['server']};"
        f"DATABASE={DB_CONFIG['database']};"
        f"UID={DB_CONFIG['username']};"
        f"PWD={DB_CONFIG['password']};"
        f"TrustServerCertificate={DB_CONFIG['trust_server_certificate']};"
    )

def get_db_connection():
    try:
        conn = pyodbc.connect(get_connection_string())
        return conn
    except Exception as e:
        print(f"❌ خطا در اتصال به دیتابیس: {e}")
        return None

def execute_query(query, params=None):
    conn = get_db_connection()
    if conn is None:
        return None
    try:
        cursor = conn.cursor()
        if params:
            cursor.execute(query, params)
        else:
            cursor.execute(query)
        rows = cursor.fetchall()
        conn.close()
        return rows
    except Exception as e:
        print(f"❌ خطا در اجرای کوئری: {e}")
        conn.close()
        return None

def execute_procedure(proc_name, params=None):
    conn = get_db_connection()
    if conn is None:
        return None
    try:
        cursor = conn.cursor()
        if params:
            cursor.execute(f"EXEC {proc_name} " + ", ".join(["?"] * len(params)), params)
        else:
            cursor.execute(f"EXEC {proc_name}")
        rows = cursor.fetchall()
        conn.commit()
        conn.close()
        return rows
    except Exception as e:
        print(f"❌ خطا در اجرای Procedure: {e}")
        conn.close()
        return None

def execute_function(func_name, params=None):
    conn = get_db_connection()
    if conn is None:
        return None
    try:
        cursor = conn.cursor()
        if params:
            placeholders = ", ".join(["?"] * len(params))
            query = f"SELECT dbo.{func_name}({placeholders}) AS Result"
            cursor.execute(query, params)
        else:
            query = f"SELECT dbo.{func_name}() AS Result"
            cursor.execute(query)
        row = cursor.fetchone()
        conn.close()
        return row.Result if row else None
    except Exception as e:
        print(f"❌ خطا در اجرای Function: {e}")
        conn.close()
        return None